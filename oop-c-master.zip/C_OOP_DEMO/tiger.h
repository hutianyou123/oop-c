#ifndef __TIGER_H__
#define __TIGER_H__

#include "oop_common.h"

ObjectPtr Tiger_New();
void Tiger_Delete(ObjectPtr obj);

#endif  //__TIGER_H__
