#ifndef __SWALLOW_H__
#define __SWALLOW_H__

#include "oop_common.h"

ObjectPtr Swallow_New();
void Swallow_Delete(ObjectPtr obj);

#endif  //__SWALLOW_H__
