#ifndef __BAT_H__
#define __BAT_H__

#include "oop_common.h"

ObjectPtr Bat_New();
void Bat_Delete(ObjectPtr obj);

#endif  //__BAT_H__
