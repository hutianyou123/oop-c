#ifndef __PENGUIN_H__
#define __PENGUIN_H__

#include "oop_common.h"

ObjectPtr Penguin_New();
void Penguin_Delete(ObjectPtr obj);

#endif  //__PENGUIN_H__
