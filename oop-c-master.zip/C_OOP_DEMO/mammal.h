#ifndef __MAMMAL_H__
#define __MAMMAL_H__

#include "oop_common.h"

ObjectPtr Mammal_New();
void Mammal_Delete(ObjectPtr obj);

#endif  //__MAMMAL_H__
