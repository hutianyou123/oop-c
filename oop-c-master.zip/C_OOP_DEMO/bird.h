#ifndef __BIRD_H__
#define __BIRD_H__

#include "oop_common.h"

ObjectPtr Bird_New();
void Bird_Delete(ObjectPtr obj);

#endif  //__BIRD_H__
